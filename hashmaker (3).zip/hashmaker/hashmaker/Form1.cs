﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace hashmaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string data = "Hello, World!"; // Data to be hashed
            string hmacsha256hash = GWTHIMAC(data, "MySercetKey", new HMACSHA256());
            MessageBox.Show(hmacsha256hash);
            

        }
        static string GWTHIMAC(string input,string key,HMAC algorthims)
        {
            byte[] keybytes=Encoding.UTF8.GetBytes(key);
            algorthims.Key = keybytes;
            byte[] data=algorthims.ComputeHash(Encoding.UTF8.GetBytes(input));
            StringBuilder sb = new StringBuilder();
            foreach(byte b in data)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

    }
}
